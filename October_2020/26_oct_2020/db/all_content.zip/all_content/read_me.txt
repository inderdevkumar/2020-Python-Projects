Points to taken care:
backend.py is the backend python file. Dealing only operation with database
front_end- This is the program you have to run.
inderdev- Is the database that will contains tables "synsets" and "phrases"
original_phrases.xlsx - This is the original phrases data
originalsynsets.xlsx- This is the original synsets data
phrases- This is the phrases data used in testing my code 
synsets-  This is the synsets data used in testing my code

To test th the code with example of "jail"
Please run front_end.py

To test for any phrase 
kindly insert the original_phrases.xlsx and originalsynsets.xlsx first in db  by first calling delete() for each tabale and than insert_phrases() and insert_synsets().

Note: This insertion is taking too much time, ie. why I have not inserted all.